<?php
namespace Omeka\Api\Exception;

class BadResponseException extends RuntimeException
{
}
