<?php
namespace Omeka\Api\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
