<?php
namespace Omeka\Api\Exception;

class OperationNotImplementedException extends BadRequestException
{
}
