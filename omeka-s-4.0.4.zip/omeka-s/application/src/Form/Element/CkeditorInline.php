<?php
namespace Omeka\Form\Element;

class CkeditorInline extends HtmlTextarea
{
    protected $attributes = [
        'type' => 'ckeditor_inline',
    ];
}
