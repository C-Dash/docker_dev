<?php
namespace Omeka\File\Exception;

class InvalidThumbnailerException extends RuntimeException
{
}
