<?php
namespace Omeka\File\Exception;

class ConfigException extends \Omeka\Service\Exception\ConfigException implements ExceptionInterface
{
}
